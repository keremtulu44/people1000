Frozen v3.1 source used by the character study (2026-10-25).
No external dependencies; Python 3.11+.
Extract into an empty directory, then run:
  python -m society.character_study
  python -m society.character_study_followup
  python -m society.character_study_report
This regenerates the 508 primary and 104 exploratory follow-up runs.
Raw data are not bundled. Full historical tests/fixtures remain in the repository.
See docs/character-study-method.md for scope, interventions and missing mechanisms.
The model source hashes match both study protocols. Behavior rules were not edited.
