"""Standard-library reference engine. Time is integer simulation minutes.

Only the engine mutates reality. A provider receives a detached, local observation
and proposes an action; it never receives engine access or authoritative globals.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import asdict, dataclass, field
import heapq
import json
from pathlib import Path
import random
from typing import Protocol

from . import dynamics, collective
from .behavior import load_profile, sample_traits, validate_profile

GROUPS = {name: group["population_percent"] for name, group in load_profile()["groups"].items()}
VERSION = 2


@dataclass
class Config:
    population: int = 100
    seed: int = 44
    read_budget: int = 6
    communication_budget: int = 2
    action_budget: int = 3
    cumulative_enabled: bool = True
    ablation: str = "none"

    def __post_init__(self):
        if self.ablation not in ("none", "economic_evidence", "peer", "trust_erosion"):
            raise ValueError("Unknown diagnostic ablation")
        if type(self.cumulative_enabled) is not bool:
            raise ValueError("cumulative_enabled must be boolean")
        if type(self.seed) is not int:
            raise ValueError("Seed must be an integer")
        if type(self.population) is not int or self.population < 100 or self.population % 100:
            raise ValueError("Population must be a positive multiple of 100")
        if any(type(v) is not int or v < 0 for v in (self.read_budget, self.communication_budget, self.action_budget)):
            raise ValueError("Budgets cannot be negative")


@dataclass
class Agent:
    id: str
    initial_group: str
    alignment: str
    savings: float
    income: float
    expense: float
    traits: dict
    initial_traits: dict
    permissions: list = field(default_factory=list)
    employer: str | None = None
    authority_dependency: str | None = None
    public_support: float = 0.5
    private_loyalty: float = 0.5
    beliefs: dict = field(default_factory=dict)
    memories: list = field(default_factory=list)
    inbox: list = field(default_factory=list)
    used: dict = field(default_factory=lambda: {"read": 0, "communication": 0, "action": 0})
    budget_day: int = 0
    behavior: dict = field(default_factory=dict)
    public_alignment: str = "none"
    pressure: float = 0.0
    change_evidence: float = 0.0
    losses: float = 0.0


class DecisionProvider(Protocol):
    def decide(self, observation: dict) -> dict: ...


class BaselineProvider:
    """Deliberately simple, deterministic comparison policy; not a full AI model."""
    def decide(self, observation: dict) -> dict:
        proposal = collective.policy(observation)
        if proposal is not None:
            return proposal
        messages = [m for m in observation["messages"] if "message_id" in m]
        if messages and observation["contacts"]:
            return {"type": "relay", "message_id": messages[-1]["message_id"],
                    "target": observation["contacts"][0]}
        return {"type": "wait"}


class Simulation:
    def __init__(self, config: Config | None = None, behavior_profile: dict | None = None):
        self.config = config or Config()
        self.behavior_profile = validate_profile(behavior_profile) if behavior_profile is not None else load_profile()
        self.rng = random.Random(self.config.seed)
        self.time = 0
        self.seq = 0
        self.queue = []
        self.processed = set()
        self.log = []
        self.decisions = []
        self.agents = {}
        self.edges = []
        self.authorities = {}
        self.messages = {}
        if collective.enabled(self):
            self.gatherings = {}
        self.calls = []
        self.last_daily_day = -1
        self.price = 1.0
        self.pole_power = {"A": 80.0, "B": 80.0}
        # Frozen protocol accompanies every saved experiment.
        self.protocol = {"version": VERSION, "config": asdict(self.config),
                         "behavior_profile": deepcopy(self.behavior_profile),
                         "metrics": ["reach", "delivery_latency", "support_gap", "alignment_changes",
                                     "economic_losses", "perception_error", "rejected_actions"],
                         "failure_conditions": ["unreachable delivery", "unauthorized mutation",
                                                "duplicate application", "budget overflow"],
                         "limitations": ["uncalibrated traits", "baseline policy is not an AI",
                                         "uncalibrated cumulative dynamics", "no realism claim"]}
        self.daily_metrics = []
        self.experiment_id = "local"
        self._populate()
        self._initialize_behavior()
        if collective.enabled(self):
            for a in self.agents.values():
                collective.state(a)
        self.schedule(0, "daily", {})

    def _id(self, prefix):
        self.seq += 1
        return f"{prefix}{self.seq:08d}"

    def _populate(self):
        for group, settings in self.behavior_profile["groups"].items():
            fraction = settings["population_percent"]
            for _ in range(self.config.population * fraction // 100):
                aid = f"A{len(self.agents) + 1:04d}"
                pole = "B" if group == "opposition" else (
                    "none" if group in {"observer", "discontented"} else self.rng.choice(["A", "B"]))
                if group == "power_aligned":
                    pole = "A"
                traits = sample_traits(self.rng, settings)
                wealthy = group in {"wealthy", "authority"}
                self.agents[aid] = Agent(aid, group, pole,
                    self.rng.uniform(200, 400) if wealthy else self.rng.uniform(20, 80),
                    15.0 if wealthy else 5.0, 4.0, traits, deepcopy(traits),
                    ["pressure", "revoke_contract"] if group == "authority" else [])
        leaders = [a.id for a in self.agents.values() if a.initial_group == "authority"]
        wealthy = [a.id for a in self.agents.values() if a.initial_group == "wealthy"]
        for leader in leaders:
            a = self.agents[leader]
            self.authorities[leader] = {"pole_alignment": a.alignment, "institutional_power": 1.0,
                "allied_authorities": [x for x in leaders if x != leader and self.agents[x].alignment == a.alignment],
                "conflicting_authorities": [x for x in leaders if self.agents[x].alignment != a.alignment]}
        ids = list(self.agents)
        for a in self.agents.values():
            degree = 1 if a.initial_group == "observer" else (3 if a.initial_group == "discontented" else 5)
            for target in self.rng.sample([x for x in ids if x != a.id], degree):
                self.edges.append({"source": a.id, "target": target, "type": "close",
                                   "trust": self.rng.uniform(.3, .9), "latency": self.rng.randint(15, 180)})
            if a.initial_group != "observer":
                matches = [x for x in leaders if self.agents[x].alignment == a.alignment]
                leader = self.rng.choice(matches or leaders)
                # source -> target is information-flow direction, not who follows whom.
                if not self.edge(leader, a.id) and leader != a.id:
                    self.edges.append({"source": leader, "target": a.id, "type": "authority",
                                       "trust": self.rng.uniform(.6, .95), "latency": self.rng.randint(5, 90)})
            if a.initial_group == "wealthy":
                a.authority_dependency = self.rng.choice(leaders)
            if a.initial_group not in {"wealthy", "authority"}:
                a.employer = self.rng.choice(wealthy)

    def _initialize_behavior(self):
        for a in self.agents.values():
            if a.behavior:
                continue
            known = {}
            # Initial public affiliations of directly connected people are part of
            # the initial local world, not access to their private loyalty.
            for edge in self.edges:
                if edge["source"] == a.id or edge["target"] == a.id:
                    other = edge["target"] if edge["source"] == a.id else edge["source"]
                    person = self.agents[other]
                    known[other] = {"pole": person.public_alignment if person.public_alignment != "none" else person.alignment,
                                    "group": person.initial_group, "trust": edge["trust"]}
            dynamics.initialize(a, known)
            if a.public_alignment == "none":
                a.public_alignment = a.alignment

    def edge(self, source, target):
        return next((e for e in self.edges if e["source"] == source and e["target"] == target), None)

    def schedule(self, time: int, kind: str, payload: dict, caused_by=None):
        if type(time) is not int or time < self.time:
            raise ValueError("Events need an integer time not earlier than now")
        self._validate_event(time, kind, payload)
        eid = self._id("E")
        heapq.heappush(self.queue, (time, -self.seq if kind == "daily" else self.seq, eid, kind, deepcopy(payload), caused_by))
        return eid

    def _validate_event(self, time, kind, p):
        if not isinstance(kind, str) or not isinstance(p, dict):
            raise ValueError("Invalid event")
        if kind == "daily":
            if time % 1440:
                raise ValueError("Daily routines require a day boundary")
        elif kind == "price_shock":
            if type(p.get("multiplier")) not in (int, float) or not 0 < p["multiplier"] <= 10:
                raise ValueError("Invalid price multiplier")
        elif kind == "power_change":
            if not isinstance(p.get("pole"), str) or p["pole"] not in self.pole_power or type(p.get("value")) not in (int, float) or not 0 <= p["value"] <= 100:
                raise ValueError("Invalid power change")
        elif kind == "external_action":
            if not isinstance(p.get("actor"), str) or p["actor"] not in self.agents or not isinstance(p.get("proposal"), dict):
                raise ValueError("Invalid scheduled intervention")
        elif kind == "gathering_close":
            if not collective.enabled(self) or not isinstance(p.get("gathering_id"), str) or p["gathering_id"] not in self.gatherings:
                raise ValueError("Unknown gathering")
            if time != self.gatherings[p["gathering_id"]]["end"]:
                raise ValueError("Gathering closes at its registered end")
        elif kind == "day_end":
            pass
        elif kind in {"read", "decide", "delivery", "behavior"}:
            if not isinstance(p.get("target"), str) or p["target"] not in self.agents:
                raise ValueError("Unknown event target")
            if kind == "delivery":
                if not isinstance(p.get("sender"), str) or p["sender"] not in self.agents or not isinstance(p.get("message_id"), str) or p["message_id"] not in self.messages:
                    raise ValueError("Invalid delivery source or message")
                scope = self.messages[p["message_id"]].get("audience")
                if scope is not None and p["target"] not in scope:
                    raise ValueError("Delivery outside audience")
                sender = self.agents[p["sender"]]
                message = self.messages[p["message_id"]]
                if not self.edge(sender.id, p["target"]) or (sender.id != message["original_source"] and not any(m.get("message_id") == message["id"] for m in sender.memories)):
                    raise ValueError("Sender has no access to message or target")
        else:
            raise ValueError("Unknown event type")

    @staticmethod
    def _safe_proposal(proposal):
        # Reject non-JSON/non-finite responses without poisoning future snapshots.
        try:
            return json.loads(json.dumps(proposal, allow_nan=False))
        except (TypeError, ValueError, OverflowError):
            return {"invalid_proposal": "non-JSON or non-finite response"}

    def record(self, kind, payload, caused_by=None, event_id=None):
        eid = self._id("L")
        self.log.append({"id": eid, "time": self.time, "kind": kind,
                         "payload": deepcopy(payload), "caused_by": caused_by, "event_id": event_id})
        return eid

    def observation(self, aid):
        """No global power, price, hidden memories or other agents' private state."""
        a = self.agents[aid]
        result = deepcopy({"agent_id": aid, "time": self.time, "group": a.initial_group,
            "traits": a.traits, "alignment": a.alignment, "savings": a.savings,
            "behavior": a.behavior, "private_loyalty": a.private_loyalty, "public_support": a.public_support,
            "beliefs": a.beliefs, "messages": [m for m in a.memories if "message_id" in m][-10:], "experiences": [m for m in a.memories if "message_id" not in m][-10:], "budgets_used": a.used,
            "contacts": [e["target"] for e in self.edges if e["source"] == aid],
            "allowed_actions": ["wait", "send", "relay", "declare_support"] + a.permissions,
            "untrusted_data_fields": ["messages", "beliefs"]})
        if collective.enabled(self):
            result["social"] = collective.observe(self,a)
            result["political_responsibility"] = a.behavior.get("appraisal",{}).get("responsibility_current",0.)
            result["allowed_actions"].extend(collective.ACTIONS)
            result["untrusted_data_fields"].append("social.known_gatherings")
        return result

    def propose(self, aid, proposal, cause=None):
        """Explicit proposal boundary; permissions and identity never come from model output."""
        did = self._id("D")
        self.decisions.append({"id": did, "actor": aid, "time": self.time,
                               "proposal": self._safe_proposal(proposal), "cause": cause})
        return did

    def apply(self, did):
        if did in self.processed:
            return False
        d = next((x for x in self.decisions if x["id"] == did), None)
        if d is None:
            raise ValueError("Unknown decision")
        a = self.agents.get(d["actor"])
        p = d["proposal"]
        reason = self._validate(a, p)
        self.processed.add(did)
        if reason:
            self.record("action_rejected", {"decision": did, "reason": reason}, d["cause"])
            return False
        kind = p["type"]
        self._refresh_budget(a)
        if kind != "wait":
            a.used["action"] += 1
        if kind in {"send", "relay"}:
            a.used["communication"] += 1
            if kind == "send":
                mid = self._id("M")
                self.messages[mid] = {"id": mid, "original_source": a.id,
                    "created_at": self.time, "source_group": a.initial_group, "source_alignment": a.public_alignment if collective.enabled(self) else a.alignment, "text": p["text"], "topic": p.get("topic", "general"),
                    "claim": p.get("claim"), "audience": p.get("audience")}
                if collective.enabled(self) and p.get("gathering_id") is not None:
                    self.messages[mid]["gathering"] = collective.invitation(self,a,p["gathering_id"])
            else:
                mid = p["message_id"]
            edge = self.edge(a.id, p["target"])
            self.schedule(self.time + edge["latency"], "delivery",
                          {"message_id": mid, "sender": a.id, "target": p["target"]}, did)
        elif kind in collective.ACTIONS:
            collective.apply(self,a,p,did)
        elif kind == "declare_support":
            a.public_support = p["value"]
            a.public_alignment = a.alignment
        elif kind == "pressure":
            a.savings -= 2
            target = self.agents[p["target"]]
            target.public_alignment = a.alignment
            target.pressure = min(1.0, target.pressure + .2)
            # Limited direct economic/self-reported experience, not a global broadcast.
            target.public_support = min(1., target.public_support + target.traits["pressure_response"])
            a.public_support = max(0., a.public_support - .02)
            target.memories.append({"event_id": did, "learned_at": self.time, "type": "direct_experience", "actor": a.id, "pressure": .2})
            self.record("pressure_experienced", {"target": target.id, "actor": a.id}, did)
        elif kind == "revoke_contract":
            a.savings -= 2
            target = self.agents[p["target"]]
            loss = target.income * .3
            target.income -= loss
            target.losses += loss
            target.memories.append({"event_id": did, "learned_at": self.time,
                                    "type": "direct_experience", "income_loss": loss})
            from . import appraisal
            if appraisal.enabled(self):
                appraisal.direct_notice(self,target,a.id,a.public_alignment,loss,did)
        self.record("action_applied", {"decision": did, "actor": a.id, "type": kind, "target": p.get("target"), "public_support": a.public_support}, d["cause"])
        return True

    def _refresh_budget(self, a):
        day = self.time // 1440
        if a.budget_day != day:
            a.used = {"read": 0, "communication": 0, "action": 0}
            a.budget_day = day

    def _validate(self, a, p):
        if a is None or not isinstance(p, dict):
            return "invalid proposal or actor"
        kind = p.get("type")
        allowed = {"wait", "send", "relay", "declare_support", "pressure", "revoke_contract"}
        if collective.enabled(self):
            allowed.update(collective.ACTIONS)
        if not isinstance(kind, str) or kind not in allowed:
            return "unknown action"
        used = a.used if a.budget_day == self.time // 1440 else {"action": 0, "communication": 0}
        if kind != "wait" and used["action"] >= self.config.action_budget:
            return "action budget exhausted"
        if kind in collective.ACTIONS:
            return collective.validate(self,a,p)
        if kind in {"send", "relay"}:
            if used["communication"] >= self.config.communication_budget:
                return "communication budget exhausted"
            if not self.edge(a.id, p.get("target")):
                return "no communication path"
            if kind == "send":
                if p.get("gathering_id") is not None:
                    gid = p["gathering_id"]
                    if not collective.enabled(self) or not isinstance(gid,str) or gid not in collective.state(a)["known_gatherings"]:
                        return "gathering not learned"
                    if gid not in self.gatherings or self.time >= self.gatherings[gid]["end"]:
                        return "gathering ended"
                audience = p.get("audience")
                if audience is not None and (not isinstance(audience, list) or any(not isinstance(x, str) or x not in self.agents for x in audience) or p["target"] not in audience):
                    return "invalid or inaccessible audience"
                if not isinstance(p.get("topic", "general"), str) or not 0 < len(p.get("topic", "general")) <= 200:
                    return "invalid topic"
                if not isinstance(p.get("text"), str) or not 0 < len(p["text"]) <= 2000:
                    return "invalid message text"
                if p.get("claim") is not None and (type(p["claim"]) not in (int, float) or not 0 <= p["claim"] <= 100):
                    return "invalid claim"
            if kind == "relay" and isinstance(p.get("message_id"), str) and p.get("message_id") in self.messages:
                scope = self.messages[p["message_id"]].get("audience")
                if scope is not None and p["target"] not in scope:
                    return "outside message audience"
            if kind == "relay" and not any(m.get("message_id") == p.get("message_id") for m in a.memories):
                return "message not learned"
        if kind == "declare_support" and (type(p.get("value")) not in (int, float) or not 0 <= p["value"] <= 1):
            return "invalid support value"
        if kind in {"pressure", "revoke_contract"}:
            if kind not in a.permissions:
                return "permission denied"
            if not isinstance(p.get("target"), str) or p.get("target") not in self.agents or p["target"] == a.id:
                return "invalid target"
            target = self.agents[p["target"]]
            if target.authority_dependency != a.id:
                return "target outside authority scope"
            if a.savings < 2:
                return "insufficient resources"
        return None

    def run(self, until: int, provider: DecisionProvider | None = None, max_events=100000):
        if type(until) is not int or until < self.time:
            raise ValueError("Cannot run backwards")
        provider = provider or BaselineProvider()
        count = 0
        while self.queue and self.queue[0][0] <= until:
            if count >= max_events:
                raise RuntimeError("Event limit reached; state remains resumable")
            time, order, eid, kind, payload, cause = heapq.heappop(self.queue)
            self.time = time
            if eid in self.processed:
                continue
            # Restore an event if provider/processing fails. Provider is called before
            # decision-side mutation; persisted responses are used on a retry.
            try:
                outcome = self._handle(eid, kind, payload, provider)
            except Exception:
                heapq.heappush(self.queue, (time, order, eid, kind, payload, cause))
                raise
            self.processed.add(eid)
            self.record(kind if outcome is not False else kind + "_skipped", payload, cause, event_id=eid)
            count += 1
        self.time = until

    def _handle(self, eid, kind, p, provider):
        if kind == "daily":
            day = self.time // 1440
            if day <= self.last_daily_day:
                return False
            self.last_daily_day = day
            for a in self.agents.values():
                self._refresh_budget(a)
                expense = a.expense * self.price
                a.savings += a.income - expense
                loss = max(0., expense - a.expense)
                a.losses += loss
                # Personal expense is observable; global prices/power are not injected.
                a.memories.append({"event_id": eid, "type": "direct_experience",
                                   "learned_at": self.time, "expense": expense, "income": a.income})
                self.schedule(self.time, "read", {"target": a.id}, eid)
                self.schedule(self.time, "behavior", {"target": a.id, "expense": expense}, eid)
            self.schedule(self.time + 1439, "day_end", {}, eid)
            self.schedule(self.time + 1440, "daily", {}, eid)
        elif kind == "price_shock":
            if type(p.get("multiplier")) not in (int, float) or not 0 < p["multiplier"] <= 10:
                raise ValueError("Invalid price multiplier")
            self.price *= p["multiplier"]
        elif kind == "power_change":
            if p.get("pole") not in self.pole_power or type(p.get("value")) not in (int, float) or not 0 <= p["value"] <= 100:
                raise ValueError("Invalid power change")
            self.pole_power[p["pole"]] = p["value"]
        elif kind == "delivery":
            a = self.agents[p["target"]]
            if self.edge(p["sender"], a.id) and p["message_id"] in self.messages:
                if not any(m.get("message_id") == p["message_id"] for m in a.memories) and p["message_id"] not in [x["message_id"] for x in a.inbox]:
                    a.inbox.append({**deepcopy(p), "delivered_at": self.time})
                    self.schedule(self.time, "read", {"target": a.id}, eid)
        elif kind == "read":
            a = self.agents[p["target"]]
            self._refresh_budget(a)
            while a.inbox and a.used["read"] < self.config.read_budget:
                delivery = a.inbox.pop(0)
                m = self.messages[delivery["message_id"]]
                a.used["read"] += 1
                a.memories.append({"event_id": eid, "message_id": m["id"],
                    "learned_at": self.time, "delivered_at": delivery["delivered_at"], "sender": delivery["sender"],
                    "original_source": m["original_source"], "source_group": m["source_group"], "source_alignment": m["source_alignment"], "topic": m["topic"], "text": m["text"], "claim": m["claim"]})
                self._belief_update(a, m, delivery["sender"])
                self.schedule(self.time, "decide", {"target": a.id}, eid)
        elif kind == "external_action":
            # Admin-scheduled scenario input, never a capability given to providers.
            self.apply(self.propose(p["actor"], p["proposal"], eid))
        elif kind == "behavior":
            a = self.agents[p["target"]]
            if self.config.cumulative_enabled and self.behavior_profile["dynamics"]["enabled"]:
                dynamics.daily(self, a, p["expense"], eid)
                if collective.enabled(self):
                    local = collective.state(a)
                    withdrawal = (a.public_support > 0 and a.private_loyalty < .5 and
                        a.behavior.get("appraisal",{}).get("responsibility_current",0.) > 0)
                    ongoing = local["present_at"] is None and any(
                        g["start"] <= self.time < g["end"] for g in local["known_gatherings"].values())
                    if withdrawal or ongoing:
                        self.schedule(self.time,"decide",{"target":a.id},eid)
        elif kind == "gathering_close":
            collective.close(self,p["gathering_id"],eid)
        elif kind == "day_end":
            self.daily_metrics.append({"time": self.time, **self.behavior_metrics()})
        elif kind == "decide":
            a = self.agents[p["target"]]
            self._refresh_budget(a)
            if a.used["action"] >= self.config.action_budget:
                self.record("decision_budget_blocked", {"agent": a.id}, eid)
                return
            cached = next((c for c in self.calls if c["event"] == eid), None)
            if cached is None:
                obs = self.observation(a.id)
                response = self._safe_proposal(provider.decide(deepcopy(obs)))
                self.calls.append({"event": eid, "observation": obs, "response": deepcopy(response)})
            else:
                response = cached["response"]
            did = self.propose(a.id, response, eid)
            self.apply(did)
        else:
            raise ValueError(f"Unknown event type: {kind}")

    def _belief_update(self, a, m, sender):
        dynamics.message(self, a, m, sender)
        if collective.enabled(self):
            collective.receive(self,a,m,sender)
        from . import appraisal
        if appraisal.enabled(self) and (m["topic"].startswith("responsibility:") or m["topic"].startswith("benefit:") or m["topic"].startswith("alternative_known:")):
            return
        # In this prototype the original source is authenticated by the engine.
        # No spoofing or unverified source attribution is modeled yet.
        settings = self.behavior_profile["groups"][a.initial_group]
        if settings["requires_aligned_authority"]:
            if m["source_group"] != "authority" or m["source_alignment"] != a.alignment:
                return
        if m["claim"] is None:
            return
        edge = self.edge(sender, a.id)
        previous = a.beliefs.get(m["topic"], {}).get("estimate", 50.)
        if abs(m["claim"] - previous) / 100 < a.traits["topic_change_threshold"]:
            return
        factor = 1.
        if self.config.cumulative_enabled and self.behavior_profile["dynamics"]["enabled"]:
            if m["source_group"] == "authority":
                factor = a.traits["authority_sensitivity"] * a.behavior["trust"].get(m["original_source"], edge["trust"])
            else:
                factor = 0. if self.config.ablation == "peer" else 1-a.traits["peer_opinion_resistance"]
        weight = edge["trust"] * self.behavior_profile["belief_step"] * factor
        old_estimate = previous
        a.beliefs[m["topic"]] = {"estimate": previous + weight * (m["claim"] - previous),
                                 "evidence": m["id"], "updated_at": self.time}
        self.record("belief_updated", {"agent": a.id, "topic": m["topic"], "old": old_estimate,
            "new": a.beliefs[m["topic"]]["estimate"], "message_id": m["id"]}, m["id"])

    def behavior_metrics(self):
        agents = list(self.agents.values())
        trusts = [v for a in agents for v in a.behavior.get("trust", {}).values()]
        return {"mean_private_loyalty": sum(a.private_loyalty for a in agents)/len(agents),
                "mean_support_gap": sum(abs(a.public_support-a.private_loyalty) for a in agents)/len(agents),
                "mean_trust": sum(trusts)/len(trusts) if trusts else None,
                "alignment_changes": sum(a.behavior.get("switch_count", 0) for a in agents),
                "core_changes": sum(a.behavior.get("core_changes", 0) for a in agents),
                "losses": sum(a.losses for a in agents)}

    def metrics(self):
        agents = list(self.agents.values())
        reach = {mid: [a.id for a in agents if any(m.get("message_id") == mid for m in a.memories)] for mid in self.messages}
        latency = {mid: [m["learned_at"] - self.messages[mid]["created_at"]
                        for a in agents for m in a.memories if m.get("message_id") == mid] for mid in self.messages}
        # Only agents with an explicit estimate participate; unknown is not zero error.
        errors = [abs(a.beliefs[f"power:{pole}"]["estimate"] - value)
                  for a in agents for pole, value in self.pole_power.items() if f"power:{pole}" in a.beliefs]
        return {"time": self.time, "population": len(agents), "reach": reach,
            "delivery_latency_minutes": latency,
            "mean_support_gap": sum(abs(a.public_support - a.private_loyalty) for a in agents) / len(agents),
            "alignment_changes": sum(e["kind"] == "alignment_changed" for e in self.log),
            "losses_by_group": {g: sum(a.losses for a in agents if a.initial_group == g) for g in GROUPS},
            "perception_error": sum(errors) / len(errors) if errors else None,
            "perception_sample_count": len(errors),
            "rejected_actions": sum(e["kind"] == "action_rejected" for e in self.log),
            "provider_calls": len(self.calls)}

    def save(self, path):
        data = {"version": VERSION, "behavior_profile": self.behavior_profile, "config": asdict(self.config), "time": self.time,
                "daily_metrics": self.daily_metrics, "experiment_id": self.experiment_id, "last_daily_day": self.last_daily_day, "seq": self.seq, "queue": self.queue, "processed": sorted(self.processed),
                "agents": {k: asdict(v) for k, v in self.agents.items()}, "edges": self.edges,
                "authorities": self.authorities, "messages": self.messages, "log": self.log,
                "decisions": self.decisions, "calls": self.calls, "price": self.price,
                "pole_power": self.pole_power, "protocol": self.protocol, "rng": self.rng.getstate()}
        if collective.enabled(self):
            data["gatherings"] = self.gatherings
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(json.dumps(data, ensure_ascii=False, allow_nan=False), encoding="utf-8")
        temp.replace(path)

    @classmethod
    def load(cls, path):
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        version = data.pop("version")
        if version not in (1, VERSION):
            raise ValueError("Unsupported snapshot version")
        if version == 1:
            cls._migrate_v1(data)
        data["behavior_profile"] = validate_profile(data["behavior_profile"])
        obj = cls.__new__(cls)
        config_data = data.pop("config")
        if "cumulative_enabled" not in config_data:
            config_data["cumulative_enabled"] = False
        obj.config = Config(**config_data)
        data.setdefault("daily_metrics", [])
        data.setdefault("experiment_id", "legacy")
        def tuples(x):
            return tuple(tuples(y) for y in x) if isinstance(x, list) else x
        obj.rng = random.Random()
        obj.rng.setstate(tuples(data.pop("rng")))
        obj.agents = {k: Agent(**v) for k, v in data.pop("agents").items()}
        obj.processed = set(data.pop("processed"))
        obj.queue = [tuple(e) for e in data.pop("queue")]
        heapq.heapify(obj.queue)
        obj.__dict__.update(data)
        if collective.enabled(obj):
            obj.__dict__.setdefault("gatherings",{})
            for a in obj.agents.values():
                collective.state(a)
        obj._initialize_behavior()
        return obj

    @staticmethod
    def _migrate_v1(data):
        """Preserve historical draws/state; fill new fields without consuming RNG."""
        profile = load_profile()
        data["last_daily_day"] = max((e["time"] // 1440 for e in data["log"] if e["kind"] == "daily"), default=-1)
        data["behavior_profile"] = profile
        data["protocol"]["migration"] = "v1 -> v2; new traits use interval midpoints, no RNG draws"
        data["protocol"]["behavior_profile"] = deepcopy(profile)
        for a in data["agents"].values():
            settings = profile["groups"][a["initial_group"]]
            for field in ("traits", "initial_traits"):
                for name, bounds in settings["parameters"].items():
                    a[field].setdefault(name, a[field]["resistance"] if name == "core_orientation_resistance" else sum(bounds) / 2)
            a["budget_day"] = data["time"] // 1440
            for item in a["inbox"]:
                item.setdefault("delivered_at", data["time"])
        for m in data["messages"].values():
            source = data["agents"][m["original_source"]]
            m.setdefault("source_group", source["initial_group"])
            m.setdefault("source_alignment", source["alignment"])
        for event in data["queue"]:
            if event[3] == "daily":
                event[1] = -abs(event[1])

    def fork(self, path):
        self.save(path)
        return self.load(path)
